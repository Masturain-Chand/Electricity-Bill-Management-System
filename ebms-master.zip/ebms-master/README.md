# Electricity Bill Management System

This project was created using Java and JavaFX. It is a basic project that allows two kinds of users 1)Admin and 2)Customer. The whole software uses a database, can create, add or modify tables on its own.
Customers can check and pay bills, can recharge account using scratch cards.
Admin can setup scratch cards, set bills, check payment status.
A new customer is created as soon as someone registers with a new meter number.

You can use/modify the project according to your needs.
